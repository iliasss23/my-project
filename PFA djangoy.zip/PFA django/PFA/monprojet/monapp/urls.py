from django.contrib import admin
from django.urls import path
from monapp import views as main_views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),

    path('signup/', main_views.signup, name='signup'),

    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),

    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    path('', main_views.dashboard, name='dashboard'),

    path('complaints/submit/', main_views.submit_complaint, name='submit_complaint'),
    path('complaints/', main_views.complaints_list, name='complaints_list'),
    path('complaints/<int:complaint_id>/', main_views.complaint_detail, name='complaint_detail'),

    path('staff/complaints/', main_views.staff_complaints_list, name='staff_complaints_list'),
    path('staff/complaints/<int:complaint_id>/update/', main_views.staff_complaint_update, name='staff_complaint_update'),

    path('documents/request/', main_views.document_request, name='document_request'),
    path('documents/', main_views.document_requests_list, name='document_requests_list'),

    path('notifications/', main_views.notifications_list, name='notifications_list'),
    path('notifications/read/<int:notif_id>/', main_views.mark_notification_read, name='mark_notification_read'),
]
