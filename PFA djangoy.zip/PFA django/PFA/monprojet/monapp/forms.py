# mainapp/forms.py

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Complaint, DocumentRequest

class CitizenSignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")

from django import forms
from .models import Complaint, DocumentRequest

class ComplaintForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ['title', 'complaint_type', 'description', 'location', 'image']

class ComplaintUpdateForm(forms.ModelForm):
    # للموظفين لتحديث الحالة والرد
    class Meta:
        model = Complaint
        fields = ['status', 'response']

class DocumentRequestForm(forms.ModelForm):
    class Meta:
        model = DocumentRequest
        fields = ['document_type', 'supporting_documents']
