# mainapp/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required ,user_passes_test
from django.contrib import messages
from .forms import CitizenSignUpForm, ComplaintForm, ComplaintUpdateForm, DocumentRequestForm
from .models import Complaint, DocumentRequest, Notification, Profile
from django.contrib.auth.models import User

def signup(request):
    if request.method == 'POST':
        form = CitizenSignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            Profile.objects.create(user=user, user_type='citizen')
            login(request, user)
            return redirect('dashboard')
    else:
        form = CitizenSignUpForm()
    return render(request, 'registration/signup.html', {'form': form})

@login_required
def dashboard(request):
    profile = Profile.objects.get(user=request.user)
    context = {'profile': profile}
    return render(request, 'dashboard.html', context)

@login_required
def submit_complaint(request):
    if request.method == "POST":
        form = ComplaintForm(request.POST, request.FILES)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.user = request.user
            complaint.save()
            messages.success(request, "Votre plainte a été soumise avec succès.")
            return redirect('complaints_list')
    else:
        form = ComplaintForm()
    return render(request, 'submit_complaint.html', {'form': form})

@login_required
def complaints_list(request):
    complaints = Complaint.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'complaints_list.html', {'complaints': complaints})

@login_required
def complaint_detail(request, complaint_id):
    complaint = get_object_or_404(Complaint, pk=complaint_id)
    # يمكن للمستخدم فقط عرض شكاويه أو الموظفين (حسب صلاحيات)
    if complaint.user != request.user and not request.user.is_staff:
        messages.error(request, "Accès refusé.")
        return redirect('complaints_list')

    # عرض التفاصيل فقط
    return render(request, 'complaint_detail.html', {'complaint': complaint})

# تحقق من أن المستخدم موظف
def is_staff(user):
    return user.is_staff

@login_required
@user_passes_test(is_staff)
def staff_complaints_list(request):
    # الموظفين يرون جميع الشكاوى
    complaints = Complaint.objects.all().order_by('-created_at')
    return render(request, 'staff_complaints_list.html', {'complaints': complaints})

@login_required
@user_passes_test(is_staff)
def staff_complaint_update(request, complaint_id):
    complaint = get_object_or_404(Complaint, pk=complaint_id)
    if request.method == "POST":
        form = ComplaintUpdateForm(request.POST, instance=complaint)
        if form.is_valid():
            form.save()
            # تنبيه المستخدم برسالة عن تحديث الشكوى
            Notification.objects.create(
                user=complaint.user,
                message=f"Votre plainte '{complaint.title}' a été mise à jour. Statut : {complaint.get_status_display()}."
            )
            messages.success(request, "Mise à jour réussie.")
            return redirect('staff_complaints_list')
    else:
        form = ComplaintUpdateForm(instance=complaint)
    return render(request, 'staff_complaint_update.html', {'form': form, 'complaint': complaint})

@login_required
def document_request(request):
    if request.method == "POST":
        form = DocumentRequestForm(request.POST, request.FILES)
        if form.is_valid():
            doc_req = form.save(commit=False)
            doc_req.user = request.user
            doc_req.save()
            messages.success(request, "Demande de document envoyée.")
            return redirect('document_requests_list')
    else:
        form = DocumentRequestForm()
    return render(request, 'document_request.html', {'form': form})

@login_required
def document_requests_list(request):
    docs = DocumentRequest.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'document_requests_list.html', {'documents': docs})

@login_required
def notifications_list(request):
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'notifications_list.html', {'notifications': notifications})

@login_required
def mark_notification_read(request, notif_id):
    notification = get_object_or_404(Notification, pk=notif_id, user=request.user)
    notification.is_read = True
    notification.save()
    return redirect('notifications_list')



