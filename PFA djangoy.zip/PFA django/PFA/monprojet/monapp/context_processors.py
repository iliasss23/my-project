from .models import Notification

def unread_notifications_count(request):
    count = 0
    if request.user.is_authenticated:
        count = Notification.objects.filter(user=request.user, read=False, is_deleted=False).count()
    
    return {'notifications_unread_count': count}

def unread_notifications_count_admin(request):
    count_admin = 0
    if request.user.is_authenticated and request.user.is_staff:
        count_admin = Notification.objects.filter(
            user=request.user,
            read=False,
            is_deleted=False
        ).count()

    return {'notifications_unread_count_admin': count_admin}