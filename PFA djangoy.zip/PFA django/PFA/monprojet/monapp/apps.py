from django.apps import AppConfig

class MonappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'monapp'

    def ready(self):
        import monapp.signals  # ← هذا السطر مهم جدًا لربط signals
