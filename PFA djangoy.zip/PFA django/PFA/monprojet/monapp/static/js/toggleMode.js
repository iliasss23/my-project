document.addEventListener("DOMContentLoaded", function () {
    var toggle_btn;
    var big_wrapper;

    function declare() {
        toggle_btn = document.querySelector(".toggle-btn");
        big_wrapper = document.querySelector(".big-wrapper");
    }

    const main = document.querySelector("main");

    declare();

    // Vérifier si le bouton toggle existe
    if (!toggle_btn) {
        console.log("Le bouton toggle-btn n'est pas présent sur cette page.");
        return; // Si le bouton n'existe pas, on quitte la fonction
    }

    // Vérifier l'état du mode sombre dans localStorage
    let dark = localStorage.getItem("darkMode") === "true";

    // Appliquer le mode sombre au chargement de la page si nécessaire
    if (dark) {
        big_wrapper.classList.add("dark");
    } else {
        big_wrapper.classList.add("light");
    }

    function toggleAnimation() {
        dark = !dark; 


        if (dark) {
            big_wrapper.classList.remove("light");
            big_wrapper.classList.add("dark");
        } else {
            big_wrapper.classList.remove("dark");
            big_wrapper.classList.add("light");
        }

        localStorage.setItem("darkMode", dark);
    }

    function events() {
        if (toggle_btn) {
            toggle_btn.addEventListener("click", toggleAnimation);
        } else {
            console.error("Le bouton toggle-btn est introuvable !");
        }
    }

    events(); 
});
