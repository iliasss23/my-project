function showForm(formType) {
  document
    .getElementById("loginForm")
    .classList.toggle("hidden", formType !== "login");
  document
    .getElementById("signupForm")
    .classList.toggle("hidden", formType !== "signup");
  document
    .getElementById("loginTab")
    .classList.toggle("active", formType === "login");
  document
    .getElementById("signupTab")
    .classList.toggle("active", formType === "signup");
}
